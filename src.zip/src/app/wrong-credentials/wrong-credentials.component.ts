import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-wrong-credentials',
  templateUrl: './wrong-credentials.component.html',
  styleUrls: ['./wrong-credentials.component.css']
})
export class WrongCredentialsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
