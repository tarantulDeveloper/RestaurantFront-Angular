import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-already-exists',
  templateUrl: './already-exists.component.html',
  styleUrls: ['./already-exists.component.css']
})
export class AlreadyExistsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
