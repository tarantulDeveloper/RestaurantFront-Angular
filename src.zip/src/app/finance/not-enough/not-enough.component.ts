import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-not-enough',
  templateUrl: './not-enough.component.html',
  styleUrls: ['./not-enough.component.css']
})
export class NotEnoughComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
