export class Task {
    work: string
    emp_id: string
}