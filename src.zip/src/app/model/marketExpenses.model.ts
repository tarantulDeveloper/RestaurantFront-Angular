export class MarketExpenses {
    id: number
    instagram: number
    facebook: number
    lalafo: number
}