export class Employee {
    userName: string
    userPassword: string
    department: string
    salary: number
    role: string
    jobBegin: string
    jobEnd: string
    branch: string
    experience: number
    firstName: string
    lastName: string
    enable: number
    
}